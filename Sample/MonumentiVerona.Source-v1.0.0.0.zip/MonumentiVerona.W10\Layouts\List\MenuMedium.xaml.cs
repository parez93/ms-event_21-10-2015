using AppStudio.Controls;

namespace MonumentiVerona.Layouts.List
{
    public sealed partial class MenuMedium : ListLayoutBase
    {
        public MenuMedium() : base()
        {
            this.InitializeComponent();
        }

        //protected override double VBPDesiredWidth0 { get { return 75; } }
        //protected override double VBPImageHeight0 { get { return 60; } }
        //protected override double VBPItemHeight0 { get { return 110; } }
        //protected override double VBPDesiredWidth1 { get { return 75; } }
        //protected override double VBPImageHeight1 { get { return 75; } }
        //protected override double VBPItemHeight1 { get { return 120; } }
        //protected override double VBPDesiredWidth2 { get { return 110; } }
        //protected override double VBPImageHeight2 { get { return 110; } }
        //protected override double VBPItemHeight2 { get { return 210; } }
        //protected override double VBPDesiredWidth3 { get { return 140; } }
        //protected override double VBPImageHeight3 { get { return 140; } }
        //protected override double VBPItemHeight3 { get { return 250; } }
        //protected override double VBPDesiredWidth4 { get { return 180; } }
        //protected override double VBPImageHeight4 { get { return 180; } }
        //protected override double VBPItemHeight4 { get { return 300; } }
        //protected override double VBPDesiredWidth5 { get { return 220; } }
        //protected override double VBPImageHeight5 { get { return 220; } }
        //protected override double VBPItemHeight5 { get { return 350; } }

        //protected override ResponsiveGridView GridView()
        //{
        //    return responsiveGridView;
        //}
    }
}
