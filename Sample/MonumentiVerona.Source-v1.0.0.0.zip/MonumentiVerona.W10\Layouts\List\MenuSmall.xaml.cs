using AppStudio.Controls;

namespace MonumentiVerona.Layouts.List
{
    public sealed partial class MenuSmall : ListLayoutBase
    {
        public MenuSmall() : base()
        {
            this.InitializeComponent();
        }

        //protected override double VBPImageWidth0 { get { return 80; } }
        //protected override double VBPItemHeight0 { get { return 80; } }
        //protected override double VBPImageWidth1 { get { return 80; } }
        //protected override double VBPItemHeight1 { get { return 80; } }
        //protected override double VBPImageWidth2 { get { return 100; } }
        //protected override double VBPItemHeight2 { get { return 100; } }
        //protected override double VBPImageWidth3 { get { return 140; } }
        //protected override double VBPItemHeight3 { get { return 140; } }
        //protected override double VBPImageWidth4 { get { return 200; } }
        //protected override double VBPItemHeight4 { get { return 200; } }
        //protected override double VBPImageWidth5 { get { return 250; } }
        //protected override double VBPItemHeight5 { get { return 250; } }

        //protected override ResponsiveGridView GridView()
        //{
        //    return responsiveGridView;
        //}
    }
}
