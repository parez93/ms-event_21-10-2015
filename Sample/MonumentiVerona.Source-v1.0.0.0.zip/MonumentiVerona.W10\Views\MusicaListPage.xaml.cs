using Windows.UI.Xaml.Navigation;
using AppStudio.Common;
using AppStudio.DataProviders.DynamicStorage;
using MonumentiVerona;
using MonumentiVerona.Sections;
using MonumentiVerona.ViewModels;

namespace MonumentiVerona.Views
{
    public sealed partial class MusicaListPage : PageBase     {
        public MusicaListPage()
        {
            this.ViewModel = new ListViewModel<DynamicStorageDataConfig, Musica1Schema>(new MusicaConfig());
            this.InitializeComponent();
}

        public ListViewModel<DynamicStorageDataConfig, Musica1Schema> ViewModel { get; set; }
        protected async override void LoadState(object navParameter)
        {
            await this.ViewModel.LoadDataAsync();
        }

    }
}
