using System.Windows.Input;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace MonumentiVerona.Layouts.List
{
    public sealed partial class MenuBig : ListLayoutBase
    {
        public MenuBig()
        {
            this.InitializeComponent();
        }
    }
}
