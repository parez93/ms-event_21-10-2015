﻿WINDOWS APP STUDIO. GENERATED CODE README

This folder contains the code for the Windows 10 app you created in Windows App Studio.

To compile this version you will need Visual Studio 2015 that you can download from here:
https://www.visualstudio.com/downloads/download-visual-studio-vs

Help and support in the Windows App Studio Forum: 
http://social.msdn.microsoft.com/Forums/wpapps/en-US/home?forum=wpappstudio