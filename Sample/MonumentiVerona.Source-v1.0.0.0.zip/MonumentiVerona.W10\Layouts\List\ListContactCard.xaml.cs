using AppStudio.Controls;

namespace MonumentiVerona.Layouts.List
{
    public sealed partial class ListContactCard : ListLayoutBase
    {
        public ListContactCard()
        {
            this.InitializeComponent();
        }
    }
}
