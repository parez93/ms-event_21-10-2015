using System;
using System.Collections.Generic;
using AppStudio.Common.Navigation;
using AppStudio.DataProviders;
using AppStudio.DataProviders.Core;
using AppStudio.DataProviders.LocalStorage;
using MonumentiVerona.Config;
using MonumentiVerona.ViewModels;

namespace MonumentiVerona.Sections
{
    public class MonumentiConfig : SectionConfigBase<LocalStorageDataConfig, Monumenti1Schema>
    {
        public override DataProviderBase<LocalStorageDataConfig, Monumenti1Schema> DataProvider
        {
            get
            {
                return new LocalStorageDataProvider<Monumenti1Schema>();
            }
        }

        public override LocalStorageDataConfig Config
        {
            get
            {
                return new LocalStorageDataConfig
                {
                    FilePath = "/Assets/Data/Monumenti.json"
                };
            }
        }

        public override NavigationInfo ListNavigationInfo
        {
            get 
            {
                return NavigationInfo.FromPage("MonumentiListPage");
            }
        }

        public override ListPageConfig<Monumenti1Schema> ListPage
        {
            get 
            {
                return new ListPageConfig<Monumenti1Schema>
                {
                    Title = "Monumenti",

                    LayoutBindings = (viewModel, item) =>
                    {
                        viewModel.Title = item.Nome.ToSafeString();
                        viewModel.SubTitle = item.Descrizione.ToSafeString();
                        viewModel.Description = "";
                        viewModel.Image = item.Immagine.ToSafeString();

                    },
                    NavigationInfo = (item) =>
                    {
                        return NavigationInfo.FromPage("MonumentiDetailPage", true);
                    }
                };
            }
        }

        public override DetailPageConfig<Monumenti1Schema> DetailPage
        {
            get
            {
                var bindings = new List<Action<ItemViewModel, Monumenti1Schema>>();

                bindings.Add((viewModel, item) =>
                {
                    viewModel.PageTitle = "Detail";
                    viewModel.Title = item.Nome.ToSafeString();
                    viewModel.Description = item.Descrizione.ToSafeString();
                    viewModel.Image = item.Immagine.ToSafeString();
                    viewModel.Content = null;
                });

				var actions = new List<ActionConfig<Monumenti1Schema>>
				{
				};

                return new DetailPageConfig<Monumenti1Schema>
                {
                    Title = "Monumenti",
                    LayoutBindings = bindings,
                    Actions = actions
                };
            }
        }

        public override string PageTitle
        {
            get { return "Monumenti"; }
        }

    }
}
