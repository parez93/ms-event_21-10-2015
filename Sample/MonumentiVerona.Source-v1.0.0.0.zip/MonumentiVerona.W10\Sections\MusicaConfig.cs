using System;
using System.Collections.Generic;
using AppStudio.Common;
using AppStudio.Common.Actions;
using AppStudio.Common.Commands;
using AppStudio.Common.Navigation;
using AppStudio.DataProviders;
using AppStudio.DataProviders.Core;
using AppStudio.DataProviders.DynamicStorage;
using Windows.Storage;
using MonumentiVerona.Config;
using MonumentiVerona.ViewModels;

namespace MonumentiVerona.Sections
{
    public class MusicaConfig : SectionConfigBase<DynamicStorageDataConfig, Musica1Schema>
    {
        public override DataProviderBase<DynamicStorageDataConfig, Musica1Schema> DataProvider
        {
            get
            {
                return new DynamicStorageDataProvider<Musica1Schema>();
            }
        }

        public override DynamicStorageDataConfig Config
        {
            get
            {
                return new DynamicStorageDataConfig
                {
                    Url = new Uri("http://ds.winappstudio.com/api/data/collection?dataRowListId=bfa1f3e3-ac31-412c-bae9-bf9c92d02660&appId=f8d2cce8-c8b2-44c8-83c5-9d0378be299a"),
                    AppId = "f8d2cce8-c8b2-44c8-83c5-9d0378be299a",
                    StoreId = ApplicationData.Current.LocalSettings.Values[LocalSettingNames.StoreId] as string,
                    DeviceType = ApplicationData.Current.LocalSettings.Values[LocalSettingNames.DeviceType] as string
                };
            }
        }

        public override NavigationInfo ListNavigationInfo
        {
            get 
            {
                return NavigationInfo.FromPage("MusicaListPage");
            }
        }

        public override ListPageConfig<Musica1Schema> ListPage
        {
            get 
            {
                return new ListPageConfig<Musica1Schema>
                {
                    Title = "Musica",

                    LayoutBindings = (viewModel, item) =>
                    {
                        viewModel.Title = item.Title.ToSafeString();
                        viewModel.SubTitle = item.ReleaseDate.ToSafeString();
                        viewModel.Description = null;
                        viewModel.Image = item.ImageUrl.ToSafeString();

                    },
                    NavigationInfo = (item) =>
                    {
                        return NavigationInfo.FromPage("MusicaDetailPage", true);
                    }
                };
            }
        }

        public override DetailPageConfig<Musica1Schema> DetailPage
        {
            get
            {
                var bindings = new List<Action<ItemViewModel, Musica1Schema>>();

                bindings.Add((viewModel, item) =>
                {
                    viewModel.PageTitle = item.Title.ToSafeString();
                    viewModel.Title = "";
                    viewModel.Description = item.ReleaseDate.ToSafeString();
                    viewModel.Image = item.ImageUrl.ToSafeString();
                    viewModel.Content = null;
                });

                bindings.Add((viewModel, item) =>
                {
                    viewModel.PageTitle = "Tracks";
                    viewModel.Title = "";
                    viewModel.Description = item.Description.ToSafeString();
                    viewModel.Image = "";
                    viewModel.Content = null;
                });

				var actions = new List<ActionConfig<Musica1Schema>>
				{
                    ActionConfig<Musica1Schema>.Play("Play", (item) => item.Link.ToSafeString()),
				};

                return new DetailPageConfig<Musica1Schema>
                {
                    Title = "Musica",
                    LayoutBindings = bindings,
                    Actions = actions
                };
            }
        }

        public override string PageTitle
        {
            get { return "Musica"; }
        }

    }
}
