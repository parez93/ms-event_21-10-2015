using AppStudio.Controls;

namespace MonumentiVerona.Layouts.List
{
    public sealed partial class ListBigVerticalCard : ListLayoutBase
    {
        public ListBigVerticalCard()
        {
            this.InitializeComponent();
        }
    }
}
