using Windows.UI.Xaml.Navigation;
using AppStudio.Common;
using AppStudio.DataProviders.LocalStorage;
using MonumentiVerona;
using MonumentiVerona.Sections;
using MonumentiVerona.ViewModels;

namespace MonumentiVerona.Views
{
    public sealed partial class MonumentiListPage : PageBase     {
        public MonumentiListPage()
        {
            this.ViewModel = new ListViewModel<LocalStorageDataConfig, Monumenti1Schema>(new MonumentiConfig());
            this.InitializeComponent();
}

        public ListViewModel<LocalStorageDataConfig, Monumenti1Schema> ViewModel { get; set; }
        protected async override void LoadState(object navParameter)
        {
            await this.ViewModel.LoadDataAsync();
        }

    }
}
