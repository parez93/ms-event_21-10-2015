using System;
using AppStudio.DataProviders;

namespace MonumentiVerona.Sections
{
    /// <summary>
    /// Implementation of the Monumenti1Schema class.
    /// </summary>
    public class Monumenti1Schema : SchemaBase
    {

        public string Nome { get; set; }

        public string Immagine { get; set; }

        public string Descrizione { get; set; }
    }
}
